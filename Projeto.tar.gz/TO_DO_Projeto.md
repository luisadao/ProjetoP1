TO-DO LIST PROJETO

FUNCOES:

	-Inserir membros (MAX 200):
		Algoritmo:
			-Verifica se o vetor dos membros esta cheio:
				->SE SIM:
					-ERROR - APENAS PODE INSERIR 200 MEMBROS NA COMUNIDADE
				->SE NAO:
					-INSERE NOVO MEMBRO	
						-Pede:
							-Nº SNS (Unico)
								-VERIFICA SE JA EXISTE ESTE N SNS:
									->SE SIM:
										-ERROR - JA EXISTE UM MEMBRO COM ESSE N SNS
									->SE NAO:
										-PEDE:	
											-Nome
											-TipoMembro (1,2,3) 
											-Ano Nascimento
											-EstadoConfinamento
												-Verifica se esta em confinamento:
													->SE SIM:
														-PEDE O TIPO DE CONFINAMENTO
													->SE NAO:
														-Estado de confinamento = nao confinado	
											-EstadoVacina
												-Verifica se ja levou vacina:
													->SE SIM:
														-Data ultima vacina								
													->SE NAO:
														-Data da ultima vacina fica vazia
		-Atencoes a ter:
			-Se o SNS é repetido
			-Se ha espaco para inserir novo membro


	
	-Listar membros:	
		Algoritmo:
			-Verificar se existem membros:
				->SE SIM:
					-Mostra os dados da comunidade
				->SE NAO:	
					-ERROR - NAO EXISTEM MEMBROS NA COMUNIDADE
					-Perguntar se quer inserir novo membro:
						->SE SIM:
							-Chamar a funcao inserir Membro
						->SE NAO:
							-Sair da funcao	
			
			
		
		-Atencoes a ter:
			-Se ha membros 
				->Se SIM mostra
				->SENAO mostra ERRO
				
				

	-Registar/Atualizar Estado Vacina:
		ALgoritmo:		
			-Se ha membros 
				->Se SIM
					-Faz:
						-Pede o SNS
						-Verifica se o SNS existe
							->SE SIM:
								-Altera o estado vacina
							->SENAO 
								-Mostra ERRO
				->Se NAO:
					-Mostra erro de nao ter membros
		
		-Atencoes a ter:
			-Se ha membros
			-Se ha o SNS indicado


	-Registar/Atualizar Estado Confinamento:		
		Algoritmo:
			-Se ha membros 
				->Se SIM:
					-Faz:
						-Backup do vetor Membros
						-Pede o SNS
						-Verifica se o SNS existe
							->Se sim:
								-Altera o estado do confinamento
							->Se nao:
								-ERRO - SNS NAO EXISTE	
		
				->SENAO mostra ERRO
				
		-Atencoes a ter:
			-Se ha membros
			-Se o SNS indicado existe

	

	-Agendar Realizacao de um teste: 
			Algoritmo:
				-Pedir o N do SNS de quem quer realizar o teste
					->Se existir
						-Pede tipo de teste
							->Se for PCR
								-Pedir a data
									->Verificar se ha disponibilidade de realizar o teste PCR (MAX 15 testes por dia)
										->Se há
											-Marcar Teste
											-QuantTestes agendados++
							->Se for Antigénio
											-Marcar Teste
											-QuantTestes agendados++
							
					->Se nao existir
						-Mostrar Erro
						-Perguntar se quer registar alguem com esse numero
							->SE SIM	
								-chamar FUNCAO INSERIR MEMBRO
							->SE NAO
								-Sair
			
			-Atencoes a ter:
				-Se o limite de testes PCR por dia ja foi atingido (15 por dia)
				-Se ha membros registados
				-Se o SNS indicado existe
				


	-Listar os dados de TODOS os TESTES:
		
		Algoritmo:
			->SE Teste ja foi realizado
				-Mostrar
					-Codigo
					-Tipo de TESTE
					-Data
					-Num SNS de quem fez
					-Resultado
					-Hora de colheita
					-Duracao
					
			->SE NAO foi realizado
				-Mostrar
					-Codigo
					-Tipo de TESTE
					-Data
					-Num SNS de quem  agendou

	-Alterar data de um teste:
		Algoritmo:
			-Pede o codigo do teste:
				->SE EXISTE
					-Verificar se é teste PCR:
						->SE SIM
							-Pede a data nova do teste
							-Verifica se ha disponibilidade para realizar o teste(MAX 15 PCR POR DIA):
								->SE SIM
									-Altera a data
								->SE NAO
									-Mostra erro de nao haver disponibilidade nesse dia
									-Pede outra data e repete as mesmas precauções
						->SE NAO É PCR (Antigenio)
							-Pede a data nova do teste
				->SE NAO EXISTE
					-Sai OU Pergunta se quer marcar o teste
					

	-Registar o Resultado de um Teste Agendado:
		Algoritmo:
			-Verifica se ha membros na comunidade:
				->SE SIM:
					-Verifica se ha testes Agendados
						->SE SIM:
							-Pedir o codigo do teste:
								->SE EXISTE:
									-Pede Resultado do teste
									-Envia os dados (Nome de quem fez , estado da vacina) para um log em ficheiro de texto
								->SE NAO EXISTE:
									-ERROR DE NAO EXISTIR
									??-Perguntar se quer marcar um teste
										->SE SIM
											-Chama a FUNCAO Agendar TESTE
										->SE NAO
											-Sair??
						->SE NAO:
							-ERROR DE NAO EXISTIR TESTES AGENDADOS
							-Perguntar se quer marcar um teste
										->SE SIM
											-Chama a FUNCAO Agendar TESTE
										->SE NAO
											-Sair
				->SE NAO:
					-ERROR DE NAO EXISTIR MEMBROS NA COMUNIDADE
					-Perguntar se quer inserir novo membro
						->SE SIM
							-Chama a FUNCAO INSERIR MEMBRO
							-Pergunta se quer marcar um teste
								->SE SIM
									-Chama a funcao Agendar TESTE
								->SE NAO
									-Sair	
						->SE NAO
							-Sair						


	-Armazenar em ficheiro binario:
		Informcaoes dos membros e dos testes agendados							

	-Apresentar Dados de um teste:
		Algoritmo:
			-Verificar se ha membros na comunidade:
				->SE SIM:
					-Verificar se ha testes realizados ou agendados:
						->SE SIM:
							-Pedir o codigo do teste ao utilizador
							-Verificar se existe teste com o codigo indicado:
								->SE SIM:
									-Mostar:
										-Dados do Teste
									 	-Nome do Membro
									 	-Tipo do Membro
									 	-Quantidade de Testes Positivos
								->SE NAO:
									-ERROR - NAO EXISTE TESTE COM O CODIGO QUE INDICOU
									-Perguntar se quer marcar teste
										->SE SIM:
											-Chamar a funcao agendar teste
										->SE NAO:
											-Sair da funcao
						->SE NAO:
							-ERROR - NAO EXISTEM TESTES AGENDADOS E/OU REALIZADOS
				->SE NAO:
					-Perguntar se quer inserir novo membro:
						->SE SIM:
							-Chamar a funcao inserir Membro
						->SE NAO:
							-Sair da funcao



	-Apresentar Dados Estatisticos:
		Algoritmo:
			-Verificar se ha membros na comunidade:
				->SE SIM:
					-Verificar se ha testes realizados:
						->SE SIM
							-Mostra:
								-Quantidade de cada tipo de membro da comunidade
								-tempo medio de cada teste
								-percentagem de testes inconclusicos
								-membros da comunidade com menor quantidade de testes realizados
								-teste(s) realizado(s) mais recente
						->SE NAO
							-ERROR - NAO EXISTEM TESTES REALIZADOS
							-Mostra:
								-Quantidade de cada tipo de membro da comunidade
								-SE EXISTIREM TESTES AGENDADOS MOSTRA O NUMERO DE TESTES AGENDADOS
				->SE NAO:
					-ERROR - NAO EXISTEM MEMBROS NA COMUNIDADE
					-Perguntar se quer inserir novo membro:
						->SE SIM:
							-Chamar a funcao inserir Membro
						->SE NAO:
							-Sair da funcao
							

	-Apresentar lista de casos de confinamento ocorridos:
		Algoritmo:
			-Verificar se ha membros na comunidade:
				->SE SIM:
					-Mostrar:
						-Informacoes do membro da comunidade
						-Tipo de confinamento (quarentena ou isolamento profilatico)
						-Data de confinamento
						-Tempo de duracao em dias									
				->SE NAO:				
					-ERROR - NAO EXISTEM MEMBROS NA COMUNIDADE
					-Perguntar se quer inserir novo membro:
						->SE SIM:
							-Chamar a funcao inserir Membro
						->SE NAO:
							-Sair da funcao		



								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
		FUNCOES A CRIAR:
			-Funcao que faz as verificacoes se existem membros e se existem testes realizados ou agendados	(Devolve 0 se existirem todos, 1 Se existirem membros mas nao existirem testes, 3 se existirem os dois);
			-


								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
								
			
		


			