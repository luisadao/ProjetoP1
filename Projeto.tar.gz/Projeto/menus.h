#ifndef MENUS_H_INCLUDED
#define MENUS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char menuPrincipal(int quantMembrosComunidade, int quantTestesAgendados, int quantMembrosVacinados, int quantTestesRealizados);
char menuVacinacao(void);
char menuConfinamento(void);
char menuTestes(void);



#endif // MENUS_H_INCLUDED
